<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <table border="1" align="center" width=100%>
        <thead>
            <tr>
                <td rowspan="3" width="30%" align="center"><img src="img/logo_bsd.png" alt="" width="200px"></td>
                <td style="text-align:center" width="40%">
                    <h3>FORMULIR</h3>
                </td>
                <td width="30%" style="padding:1rem">No. Dokumen : 1234567899</td>
            </tr>
            <td rowspan="2" style="text-align:center; padding:1rem">
                <h3>PERMINTAAN PERBAIKAN HARDWARE DAN SOFTWARE PERALATAN TOL DAN TIS </h3>
            </td>
            <td style="padding:1rem">Tgl Terbit : 1 Januari 2022</td>
            <tr>
                <td style="padding:1rem">No. Revisi : 01</td>
            </tr>
        </thead>
        <tr>
        </tr>
    </table>

    <br>

    <table align="center" width=100%>
        <tr>
        </tr>

    </table>

    <br>

    <table border="1" align="center" width=100%>
        <thead>
            <tr>
                <th style="padding:1rem" colspan="2">HARDWARE PERALATAN TOL</th>
            </tr>
            <tr>
                <th style="padding:1rem" width=50%>PLAZA GERBANG TOL</th>
                <th style="padding:1rem" width=50%>URAIAN</th>

            </tr>
            <tr>
                <td style="padding:1rem">
                    <p>Unit Plaza Computer System (PCS)</p>
                    <p>Unit Real Time Monitoring Camera System (RTM)</p>
                    <p>Unit Server CCTV Recording Computer</p>
                    <p>Printer</p>
                    <p>Hub Switch</p>
                    <p>UPS</p>
                </td>
            </tr>
            <tr>
                <th width=50%>PLAZA GERBANG TOL</th>
                <th width=50%>URAIAN</th>
            </tr>
            <tr>
                <td rowspan="3">
                    <p>Unit Plaza Computer System (PCS)</p>
                    <p>Unit Real Time Monitoring Camera System (RTM)</p>
                    <p>Unit Server CCTV Recording Computer</p>
                    <p>Printer</p>
                    <p>Hub Switch</p>
                    <p>UPS</p>
                </td>
                <td style="padding:1rem">
                    Camera Capture tidak dikonek dikarenakan jalur kabel induksi yang mengakitabkan LTCS selalu turun dan PC mati
                </td>
            </tr>
            <tr>
                <th>KONDISI AKHIR</th>
            </tr>
            <tr>
                <td style="padding:1rem">Masih pencarian induksi</td>
            </tr>
        </thead>

        <table border="1" align="center" width=100%>
            <thead>
                <tr>
                    <th style="padding:1rem" colspan="2">HARDWARE PERALATAN TIS</th>
                </tr>
                <tr>
                    <th style="padding:1rem" width=50%>TRAFFIC INFORMATION SYSTEM</th>
                    <th style="padding:1rem" width=50%>URAIAN</th>
                </tr>
                <tr>
                    <td>
                        <p>Unit Plaza Computer System (PCS)</p>
                        <p>Unit Real Time Monitoring Camera System (RTM)</p>
                        <p>Unit Server CCTV Recording Computer</p>
                        <p>Printer</p>
                        <p>Hub Switch</p>
                        <p>UPS</p>
                    </td>
                </tr>
            </thead>
        </table>

        <table border="1" width=100%>
            <thead>
                <th width=33%>User</th>
                <th width=33%>Teknisi Peralatan Tol</th>
                <th width=33%>Diketahui</th>
            </thead>
            <tbody>
                <tr height="100px">
                    <th></th>
                </tr>
                <tr>
                    <th width=33%>Nama : Muslimin</th>
                    <th width=33%>Nama : TIM IT</th>
                    <th width=33%>Nama : Mashuri Said</th>
                </tr>
            </tbody>
        </table>
</body>

</html>